module( "App" );

test( "$.Oda.App.example", function() {
    ok($.Oda.App.example(), "Test OK : Passed!" );
});