$.Oda.Context.host = "todefined";
$.Oda.Context.appBonitaName = "bonita/"
$.Oda.Context.rest = $.Oda.Context.host + $.Oda.Context.appBonitaName ;
$.Oda.Context.projectLabel = "Empty Form";
$.Oda.Context.resources = "";